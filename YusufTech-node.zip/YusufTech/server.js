const path = require("path");
const express = require("express");
const helmet = require("helmet");
const compression = require("compression");
const rateLimit = require("express-rate-limit");
const site = require("./data/site");
const icon = require("./lib/icons");

const app = express();
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.set("trust proxy", 1);
app.disable("x-powered-by");
app.use(compression());

// Serve each demo from GitHub Pages under /demos/<name>/ so visitors stay on this domain.
// Registered before helmet so the demos' own scripts and styles aren't blocked by this site's CSP.
const repos = new Map(site.projects.map((p) => [p.slug.toLowerCase(), p.slug]));
app.get(/^\/demos\/([^/]+)$/, (req, res, next) => repos.has(req.params[0].toLowerCase()) ? res.redirect(302, `/demos/${req.params[0].toLowerCase()}/`) : next());
app.get(/^\/demos\/([^/]+)\/(.*)$/, async (req, res, next) => {
  const repo = repos.get(req.params[0].toLowerCase());
  if (!repo) return next();
  const qs = req.url.includes("?") ? "?" + req.url.split("?")[1] : "";
  try {
    const r = await fetch(`https://yusufking-dev.github.io/${repo}/${req.params[1] || ""}${qs}`);
    if (!r.ok) return res.status(r.status === 404 ? 404 : 502).send("Not found");
    res.set("Content-Type", r.headers.get("content-type") || "application/octet-stream");
    res.set("Cache-Control", "public, max-age=300, s-maxage=3600");
    res.send(Buffer.from(await r.arrayBuffer()));
  } catch (err) {
    console.error("demo proxy", err.message);
    res.status(502).send("Demo temporarily unavailable");
  }
});

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "https://fonts.googleapis.com"],
      fontSrc: ["https://fonts.gstatic.com"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https://res.cloudinary.com", "https://image.thum.io"],
      connectSrc: ["'self'"],
      formAction: ["'self'"],
      frameAncestors: ["'none'"],
      upgradeInsecureRequests: null
    }
  }
}));
app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public"), { maxAge: "7d" }));

app.get("/", (req, res) => res.render("index", { site, icon }));

const limiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 5, standardHeaders: true, legacyHeaders: false,
  message: { ok: false, error: "Too many messages. Please try again in a few minutes or use WhatsApp." } });
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

app.post("/api/contact", limiter, async (req, res) => {
  const { name = "", email = "", type = "", other = "", message = "", website = "" } = req.body || {};
  if (website) return res.json({ ok: true }); // honeypot: bots fill this hidden field
  const n = String(name).trim(), e = String(email).trim(), m = String(message).trim(), t = String(type).trim(), o = String(other).trim();
  if (n.length < 2 || n.length > 80) return res.status(400).json({ ok: false, error: "Enter your name (2–80 characters)." });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e) || e.length > 120) return res.status(400).json({ ok: false, error: "Enter a valid email address." });
  if (!site.projectTypes.includes(t)) return res.status(400).json({ ok: false, error: "Choose the type of website you need." });
  if (t === "Other" && (o.length < 2 || o.length > 80)) return res.status(400).json({ ok: false, error: "Tell me what kind of website you need (2–80 characters)." });
  const kind = t === "Other" ? `Other: ${o}` : t;
  if (m.length < 10 || m.length > 2000) return res.status(400).json({ ok: false, error: "Write a message of 10–2000 characters." });
  if (!process.env.RESEND_API_KEY) return res.status(503).json({ ok: false, error: "The form isn't configured yet. Please use WhatsApp or email." });
  try {
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: process.env.CONTACT_FROM || "YUSUF TECH <onboarding@resend.dev>",
        to: [process.env.CONTACT_TO || site.email],
        reply_to: e,
        subject: `New ${kind.replace(/[\r\n]/g, " ")} enquiry from ${n.replace(/[\r\n]/g, " ")}`,
        html: `<p><b>Name:</b> ${esc(n)}<br><b>Email:</b> ${esc(e)}<br><b>Website type:</b> ${esc(kind)}</p><p>${esc(m).replace(/\n/g, "<br>")}</p>`
      })
    });
    if (!r.ok) throw new Error(`Resend ${r.status}`);
    // Auto-reply to the visitor. Awaited so serverless doesn't freeze before it sends; a failure never fails the form.
    await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: process.env.CONTACT_FROM || "YUSUF TECH <onboarding@resend.dev>",
        to: [e],
        reply_to: process.env.CONTACT_TO || site.email,
        subject: "Thanks for your message | YUSUF TECH",
        html: `<p>Hi ${esc(n)},</p><p>Thanks for getting in touch about a <b>${esc(kind)}</b> project. I've received your message and will reply within 24 hours.</p><p>If it's urgent, message me on WhatsApp: <a href="${site.socials[0].url}">${site.socials[0].url}</a></p><p>Yusuf<br>YUSUF TECH</p>`
      })
    }).catch((err) => console.error("auto-reply failed", err.message));
    res.json({ ok: true });
  } catch (err) {
    console.error(err.message);
    res.status(502).json({ ok: false, error: "Message could not be sent. Please try WhatsApp or email." });
  }
});

app.use((req, res) => res.redirect(302, "/"));

if (require.main === module) app.listen(process.env.PORT || 3000, () => console.log("YusufTech on http://localhost:" + (process.env.PORT || 3000)));
module.exports = app;
